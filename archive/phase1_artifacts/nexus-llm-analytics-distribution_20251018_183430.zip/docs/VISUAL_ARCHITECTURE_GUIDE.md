# 🎨 NEXUS LLM ANALYTICS - VISUAL ARCHITECTURE GUIDE

## 🏗️ HIGH-LEVEL SYSTEM OVERVIEW

```
┌────────────────────────────────────────────────────────────────────────────┐
│                         NEXUS LLM ANALYTICS                                │
│                   "AI-Powered Data Analysis Platform"                      │
└────────────────────────────────────────────────────────────────────────────┘

                              ┌──────────────┐
                              │     USER     │
                              │  (You/Team)  │
                              └──────┬───────┘
                                     │
                    ┌────────────────┴────────────────┐
                    │  1. Upload File                 │
                    │  2. Ask Question                │
                    │  3. Get Results                 │
                    └────────────────┬────────────────┘
                                     │
┌────────────────────────────────────▼────────────────────────────────────────┐
│                          FRONTEND (What You See)                            │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐  ┌────────────┐          │
│  │   Upload   │  │   Query    │  │  Results   │  │   Charts   │          │
│  │  Interface │  │   Input    │  │  Display   │  │  Viewer    │          │
│  └────────────┘  └────────────┘  └────────────┘  └────────────┘          │
│                                                                              │
│  Technology: React + Next.js + TypeScript + Tailwind CSS                   │
│  Port: http://localhost:3000                                                │
└─────────────────────────────┬────────────────────────────────────────────┘
                              │ HTTP/WebSocket
                              │
┌─────────────────────────────▼────────────────────────────────────────────┐
│                      API GATEWAY (Traffic Controller)                      │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐  ┌────────────┐        │
│  │  /upload   │  │  /analyze  │  │ /visualize │  │  /report   │        │
│  │  endpoint  │  │  endpoint  │  │  endpoint  │  │  endpoint  │        │
│  └────────────┘  └────────────┘  └────────────┘  └────────────┘        │
│                                                                            │
│  Technology: FastAPI + Pydantic                                            │
│  Port: http://localhost:8000                                               │
└─────────────────────────────┬──────────────────────────────────────────┘
                              │
                              │
┌─────────────────────────────▼──────────────────────────────────────────────┐
│                       CREWMANAGER (The Brain)                               │
│                        "Agent Orchestrator"                                 │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────┐            │
│  │  1. Receives your question                                 │            │
│  │  2. Understands what you need                               │            │
│  │  3. Picks the best agent(s) for the job                    │            │
│  │  4. Coordinates multiple agents to work together            │            │
│  │  5. Combines results and returns answer                     │            │
│  └────────────────────────────────────────────────────────────┘            │
└────────────────┬──────────────┬──────────────┬──────────────┬─────────────┘
                 │              │              │              │
                 ▼              ▼              ▼              ▼
         
┌────────────────────────────────────────────────────────────────────────────┐
│                         AGENT ECOSYSTEM (The Workers)                       │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────┐      │
│  │                    CORE AGENTS (Always Available)                │      │
│  │                                                                   │      │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐       │      │
│  │  │  Data    │  │   RAG    │  │  Review  │  │   Viz    │       │      │
│  │  │ Analyst  │  │Document  │  │ Quality  │  │  Chart   │       │      │
│  │  │  Agent   │  │Specialist│  │Assurance │  │Generator │       │      │
│  │  └──────────┘  └──────────┘  └──────────┘  └──────────┘       │      │
│  │       ▲              ▲              ▲              ▲            │      │
│  │       │              │              │              │            │      │
│  │  CSV/Excel      PDF/DOCX      Validates      Creates         │      │
│  │   Analysis      Processing      Results       Charts          │      │
│  └─────────────────────────────────────────────────────────────────┘      │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────┐      │
│  │               PLUGIN AGENTS (Specialized Experts)                │      │
│  │                                                                   │      │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐       │      │
│  │  │Statistical│ │Time Series│ │Financial  │ │ML Insights│       │      │
│  │  │  Expert   │ │  Expert   │ │  Expert   │ │  Expert   │       │      │
│  │  └──────────┘  └──────────┘  └──────────┘  └──────────┘       │      │
│  │       ▲              ▲              ▲              ▲            │      │
│  │  T-tests,     Forecasting,    ROI, Profit   Clustering,       │      │
│  │  ANOVA,       ARIMA,          Margins,       PCA,             │      │
│  │  Chi-Square   Seasonality     Metrics        Anomalies        │      │
│  └─────────────────────────────────────────────────────────────────┘      │
└───────────────────────┬────────────────┬───────────────────────────────────┘
                        │                │
                        ▼                ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                    AI MODEL LAYER (The Intelligence)                        │
│                                                                              │
│  ┌───────────────────────────────────────────────────────────────┐        │
│  │                     OLLAMA (Local LLM Server)                  │        │
│  │                                                                 │        │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │        │
│  │  │ llama3.1:8b  │  │  phi3:mini   │  │  tinyllama   │       │        │
│  │  │              │  │              │  │              │       │        │
│  │  │ Primary Model│  │Review Model  │  │ Low-RAM Model│       │        │
│  │  │  (8GB RAM)   │  │  (4GB RAM)   │  │  (2GB RAM)   │       │        │
│  │  └──────────────┘  └──────────────┘  └──────────────┘       │        │
│  │                                                                 │        │
│  │  Model Selector: Picks best model based on your system RAM    │        │
│  └───────────────────────────────────────────────────────────────┘        │
│                                                                              │
│  Port: http://localhost:11434                                               │
└─────────────────────────────┬──────────────────────────────────────────────┘
                              │
┌─────────────────────────────▼──────────────────────────────────────────────┐
│                      DATA LAYER (Storage & Memory)                          │
│                                                                              │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐           │
│  │  File Storage   │  │   ChromaDB      │  │   Sandbox       │           │
│  │                 │  │  Vector Store   │  │ Code Executor   │           │
│  │  data/uploads/  │  │                 │  │                 │           │
│  │  data/exports/  │  │  Document       │  │  Secure Python  │           │
│  │  reports/       │  │  Embeddings     │  │  Code Runner    │           │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘           │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

## 🔄 DATA FLOW: FROM QUESTION TO ANSWER

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      EXAMPLE: CSV ANALYSIS QUERY                            │
└─────────────────────────────────────────────────────────────────────────────┘

Step 1: USER ACTION
┌──────────────────────────────────────┐
│  User uploads: "sales_data.csv"     │
│  User asks: "What is average sales  │
│             by region?"              │
└──────────────┬───────────────────────┘
               │
               ▼
Step 2: FRONTEND PROCESSING
┌──────────────────────────────────────┐
│  • Validates file (size, type)      │
│  • Sends to /upload endpoint         │
│  • Sends query to /analyze endpoint  │
└──────────────┬───────────────────────┘
               │
               ▼
Step 3: BACKEND RECEIVES
┌──────────────────────────────────────┐
│  • File saved to data/uploads/       │
│  • Query received by API gateway     │
│  • Routed to CrewManager             │
└──────────────┬───────────────────────┘
               │
               ▼
Step 4: CREWMANAGER ANALYZES
┌──────────────────────────────────────┐
│  • Detects: CSV file                 │
│  • Intent: Statistical calculation   │
│  • Decision: Use Data Analyst Agent  │
│  • Backup: Statistical Plugin ready  │
└──────────────┬───────────────────────┘
               │
               ▼
Step 5: DATA ANALYST AGENT WORKS
┌──────────────────────────────────────┐
│  1. Loads CSV with Pandas            │
│  2. Generates Python code:           │
│     ```python                         │
│     df = pd.read_csv('file.csv')    │
│     result = df.groupby('region')   │
│                .mean()['sales']      │
│     ```                               │
│  3. Sends code to Sandbox            │
└──────────────┬───────────────────────┘
               │
               ▼
Step 6: SANDBOX EXECUTION
┌──────────────────────────────────────┐
│  • Runs code safely (isolated)       │
│  • Returns results:                  │
│    - North: $125,000                 │
│    - South: $98,500                  │
│    - East: $142,300                  │
│    - West: $110,750                  │
└──────────────┬───────────────────────┘
               │
               ▼
Step 7: REVIEW AGENT VALIDATES
┌──────────────────────────────────────┐
│  • Checks calculations ✓             │
│  • Validates data quality ✓          │
│  • Provides insights:                │
│    "East region has highest sales"   │
└──────────────┬───────────────────────┘
               │
               ▼
Step 8: VISUALIZATION AGENT
┌──────────────────────────────────────┐
│  • Creates bar chart (Plotly)        │
│  • Interactive, downloadable         │
│  • Professional styling              │
└──────────────┬───────────────────────┘
               │
               ▼
Step 9: RESPONSE FORMATTED
┌──────────────────────────────────────┐
│  {                                    │
│    "analysis": "Average sales...",   │
│    "results": {...},                 │
│    "chart": "<plotly_json>",        │
│    "insights": [...],                │
│    "review": "..."                   │
│  }                                    │
└──────────────┬───────────────────────┘
               │
               ▼
Step 10: FRONTEND DISPLAYS
┌──────────────────────────────────────┐
│  📊 RESULTS:                         │
│  ─────────────────────────────       │
│  Analysis Tab:                       │
│    "Average sales by region:"        │
│    • North: $125,000                 │
│    • South: $98,500                  │
│    • East: $142,300 (Highest)        │
│    • West: $110,750                  │
│                                       │
│  Charts Tab:                         │
│    [Interactive Bar Chart]           │
│                                       │
│  Review Tab:                         │
│    "Data quality: Excellent"         │
│                                       │
│  [Download Report Button]            │
└──────────────────────────────────────┘

⏱️ Total Time: 3-5 seconds
```

---

## 📚 DOCUMENT (RAG) PROCESSING FLOW

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      EXAMPLE: PDF DOCUMENT QUERY                            │
└─────────────────────────────────────────────────────────────────────────────┘

Step 1: USER UPLOADS PDF
┌──────────────────────────────────────┐
│  File: "research_paper.pdf"         │
│  Query: "Summarize key findings"     │
└──────────────┬───────────────────────┘
               │
               ▼
Step 2: PDF PROCESSING
┌──────────────────────────────────────┐
│  • Extract text with PyPDF2          │
│  • Split into chunks (500 words)     │
│  • Generate embeddings for each      │
│    chunk using nomic-embed-text      │
└──────────────┬───────────────────────┘
               │
               ▼
Step 3: CHROMADB STORAGE
┌──────────────────────────────────────┐
│  chroma_db/                          │
│  ├─ chunk_1_embedding [0.1, 0.3...] │
│  ├─ chunk_2_embedding [0.2, 0.1...] │
│  ├─ chunk_3_embedding [0.4, 0.2...] │
│  └─ ... (all chunks stored)          │
└──────────────┬───────────────────────┘
               │
               ▼
Step 4: RAG AGENT QUERY
┌──────────────────────────────────────┐
│  1. Convert query to embedding       │
│  2. Vector similarity search         │
│  3. Retrieve top 3 relevant chunks   │
│  4. Send to LLM for summarization    │
└──────────────┬───────────────────────┘
               │
               ▼
Step 5: LLM SUMMARIZATION
┌──────────────────────────────────────┐
│  Prompt: "Based on these excerpts,  │
│          summarize key findings..."  │
│                                       │
│  Context: [3 most relevant chunks]   │
│                                       │
│  LLM (llama3.1:8b) generates:       │
│  "The research paper examines...     │
│   Key findings include: 1) ...       │
│   2) ... 3) ..."                     │
└──────────────┬───────────────────────┘
               │
               ▼
Step 6: RESPONSE WITH SOURCES
┌──────────────────────────────────────┐
│  Summary: "..."                      │
│  Sources: [Chunk IDs, page numbers] │
│  Confidence: High                    │
└──────────────────────────────────────┘

⏱️ Total Time: 5-10 seconds
```

---

## 🔌 PLUGIN SYSTEM ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                     PLUGIN DISCOVERY & ROUTING                              │
└─────────────────────────────────────────────────────────────────────────────┘

Step 1: SYSTEM STARTUP
┌──────────────────────────────────────┐
│  CrewManager scans plugins/          │
│  ├─ statistical_agent.py             │
│  ├─ time_series_agent.py             │
│  ├─ financial_agent.py               │
│  ├─ ml_insights_agent.py             │
│  └─ sql_agent.py                     │
└──────────────┬───────────────────────┘
               │
               ▼
Step 2: PLUGIN REGISTRATION
┌──────────────────────────────────────┐
│  Each plugin declares:               │
│  • Name                               │
│  • Capabilities                       │
│  • Keywords it can handle             │
│  • Confidence scoring function        │
└──────────────┬───────────────────────┘
               │
               ▼
Step 3: USER QUERY
┌──────────────────────────────────────┐
│  Query: "Forecast next quarter sales"│
└──────────────┬───────────────────────┘
               │
               ▼
Step 4: INTELLIGENT ROUTING
┌──────────────────────────────────────┐
│  CrewManager asks each plugin:       │
│                                       │
│  Statistical: "Can you handle this?" │
│  → Score: 0.3 (can do basic stats)   │
│                                       │
│  Time Series: "Can you handle this?" │
│  → Score: 0.95 (FORECASTING!)        │
│                                       │
│  Financial: "Can you handle this?"   │
│  → Score: 0.6 (sales related)        │
│                                       │
│  Decision: Use Time Series Plugin ✓  │
└──────────────┬───────────────────────┘
               │
               ▼
Step 5: PLUGIN EXECUTION
┌──────────────────────────────────────┐
│  Time Series Plugin:                 │
│  1. Loads data                        │
│  2. Applies ARIMA model               │
│  3. Generates forecast                │
│  4. Calculates confidence intervals   │
│  5. Returns results                   │
└──────────────┬───────────────────────┘
               │
               ▼
Step 6: FALLBACK IF NEEDED
┌──────────────────────────────────────┐
│  If plugin fails:                    │
│  → Try next best (Financial Agent)   │
│  → Or use Core Data Analyst Agent    │
│  → Always have a working solution    │
└──────────────────────────────────────┘
```

---

## 🔒 SECURITY & SANDBOXING

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        SANDBOX EXECUTION FLOW                               │
└─────────────────────────────────────────────────────────────────────────────┘

Step 1: AI GENERATES CODE
┌──────────────────────────────────────┐
│  Data Agent creates:                 │
│  ```python                            │
│  import pandas as pd                 │
│  df = pd.read_csv('file.csv')       │
│  result = df['sales'].mean()        │
│  ```                                  │
└──────────────┬───────────────────────┘
               │
               ▼
Step 2: CODE REVIEW
┌──────────────────────────────────────┐
│  Review Agent checks:                │
│  ✓ No dangerous imports              │
│  ✓ No file system writes             │
│  ✓ No network calls                  │
│  ✓ No infinite loops                 │
└──────────────┬───────────────────────┘
               │
               ▼
Step 3: SANDBOX PREPARATION
┌──────────────────────────────────────┐
│  Sandbox creates isolated env:       │
│  • Limited imports (pandas, numpy)   │
│  • Memory limit: 1GB                 │
│  • CPU timeout: 30 seconds           │
│  • Read-only file access             │
└──────────────┬───────────────────────┘
               │
               ▼
Step 4: EXECUTION
┌──────────────────────────────────────┐
│  Code runs in sandbox:               │
│  ┌────────────────────────────────┐ │
│  │ Sandbox Environment            │ │
│  │ ────────────────────────────── │ │
│  │ • Can read data/uploads/       │ │
│  │ • Cannot write files           │ │
│  │ • Cannot access network        │ │
│  │ • Cannot import unsafe modules │ │
│  │ • Auto-terminates after 30s    │ │
│  └────────────────────────────────┘ │
└──────────────┬───────────────────────┘
               │
               ▼
Step 5: RESULT CAPTURE
┌──────────────────────────────────────┐
│  • Captures output                   │
│  • Catches errors safely             │
│  • Returns result or error message   │
│  • Logs execution for debugging      │
└──────────────────────────────────────┘

✅ YOUR DATA IS SAFE
✅ MALICIOUS CODE CANNOT ESCAPE
✅ SYSTEM CANNOT CRASH
```

---

## 📊 MODEL SELECTION INTELLIGENCE

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    ADAPTIVE MODEL SELECTION                                 │
└─────────────────────────────────────────────────────────────────────────────┘

System Startup:
┌──────────────────────────────────────┐
│  1. Detect system RAM                │
│  2. Check available Ollama models    │
│  3. Select optimal model             │
└──────────────┬───────────────────────┘
               │
               ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                       DECISION TREE                                         │
│                                                                              │
│  System RAM: 16GB+                    System RAM: 8GB          System RAM: 4GB │
│       │                                    │                        │         │
│       ▼                                    ▼                        ▼         │
│  ┌──────────────┐                    ┌──────────────┐        ┌─────────┐   │
│  │llama3.1:8b   │                    │ phi3:mini    │        │tinyllama│   │
│  │              │                    │              │        │         │   │
│  │Best Quality  │                    │  Balanced    │        │Fast &   │   │
│  │Comprehensive │                    │  Efficient   │        │Light    │   │
│  │Analysis      │                    │  Analysis    │        │Basic    │   │
│  └──────────────┘                    └──────────────┘        └─────────┘   │
│                                                                              │
│  Timeout: 15 min                     Timeout: 5 min          Timeout: 3 min│
└─────────────────────────────────────────────────────────────────────────────┘

Query Processing:
┌──────────────────────────────────────┐
│  Simple query?                       │
│  → Use faster model (phi3/tinyllama) │
│                                       │
│  Complex analysis?                   │
│  → Use primary model (llama3.1:8b)   │
│                                       │
│  Model fails/timeout?                │
│  → Fallback to smaller model         │
└──────────────────────────────────────┘

✅ WORKS ON ANY COMPUTER
✅ AUTOMATICALLY OPTIMIZES
✅ GRACEFUL DEGRADATION
```

---

## 🎯 FILE TYPE ROUTING

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    FILE TYPE DETECTION & ROUTING                            │
└─────────────────────────────────────────────────────────────────────────────┘

User uploads file:
       │
       ▼
┌──────────────────────────────────────┐
│  File extension detection:           │
│  .csv, .xlsx, .xls, .json           │
│       │                               │
│       ▼                               │
│  ┌──────────────────────────────┐   │
│  │   STRUCTURED DATA PATH       │   │
│  │                               │   │
│  │   1. Load with Pandas/Polars │   │
│  │   2. Route to Data Agent     │   │
│  │   3. Check for plugins:      │   │
│  │      - Statistical analysis? │   │
│  │      - Time series data?     │   │
│  │      - Financial data?       │   │
│  │   4. Execute analysis        │   │
│  └──────────────────────────────┘   │
└──────────────────────────────────────┘
       │
       │  .pdf, .docx, .txt, .rtf
       ▼
┌──────────────────────────────────────┐
│  ┌──────────────────────────────┐   │
│  │  UNSTRUCTURED DATA PATH      │   │
│  │                               │   │
│  │   1. Extract text             │   │
│  │   2. Create embeddings        │   │
│  │   3. Store in ChromaDB        │   │
│  │   4. Route to RAG Agent       │   │
│  │   5. Vector search + LLM      │   │
│  └──────────────────────────────┘   │
└──────────────────────────────────────┘
       │
       │  .sql, .db, .sqlite
       ▼
┌──────────────────────────────────────┐
│  ┌──────────────────────────────┐   │
│  │     DATABASE PATH            │   │
│  │                               │   │
│  │   1. Detect SQL plugin       │   │
│  │   2. Parse schema             │   │
│  │   3. Generate queries         │   │
│  │   4. Execute safely           │   │
│  └──────────────────────────────┘   │
└──────────────────────────────────────┘

✅ AUTOMATIC DETECTION
✅ OPTIMAL PROCESSING
✅ NO MANUAL CONFIGURATION
```

---

## 💾 DATA PERSISTENCE

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        DATA STORAGE LAYERS                                  │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│  LAYER 1: USER FILES                                                        │
│  ─────────────────────────────────────────────────────────────────────────  │
│  data/                                                                       │
│  ├── uploads/                    ← Your uploaded files                     │
│  │   ├── sales_2024.csv                                                     │
│  │   ├── report.pdf                                                         │
│  │   └── analysis.json                                                      │
│  │                                                                           │
│  ├── exports/                    ← Generated analysis files                │
│  │   ├── analysis_result.json                                               │
│  │   └── temp_charts/                                                       │
│  │                                                                           │
│  └── samples/                    ← Sample/test datasets                    │
│      └── StressLevelDataset.csv                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│  LAYER 2: VECTOR DATABASE                                                   │
│  ─────────────────────────────────────────────────────────────────────────  │
│  chroma_db/                                                                  │
│  └── Collections:                                                            │
│      └── nexus_documents/                                                    │
│          ├── Document 1: [embedding vectors]                                │
│          ├── Document 2: [embedding vectors]                                │
│          └── Metadata: {file_name, upload_date, chunks}                     │
│                                                                               │
│  Purpose: Fast semantic search for document Q&A                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│  LAYER 3: GENERATED OUTPUTS                                                 │
│  ─────────────────────────────────────────────────────────────────────────  │
│  reports/                        ← Professional reports                     │
│  ├── analysis_2024_10_12.pdf                                                │
│  └── monthly_report.xlsx                                                    │
│                                                                               │
│  logs/                           ← System activity logs                     │
│  └── nexus.log                   ← Debugging & monitoring                  │
└─────────────────────────────────────────────────────────────────────────────┘

✅ ORGANIZED STORAGE
✅ EASY TO BACKUP
✅ CLEAR SEPARATION
```

---

This visual guide should help you understand how all the pieces fit together! 🎨
