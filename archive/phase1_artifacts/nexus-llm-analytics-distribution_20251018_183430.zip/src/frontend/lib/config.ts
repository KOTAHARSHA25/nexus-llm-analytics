/**
 * Application Configuration
 * Centralized configuration for backend URLs and environment settings
 */

/**
 * Get the backend API base URL based on environment
 * Supports development, production, and custom configurations
 */
export function getBackendUrl(): string {
  // Check if running in browser
  if (typeof window !== 'undefined') {
    // Check for environment-specific override
    if (process.env.NEXT_PUBLIC_BACKEND_URL) {
      return process.env.NEXT_PUBLIC_BACKEND_URL;
    }
    
    // Production check (if hosted)
    if (window.location.hostname !== 'localhost' && window.location.hostname !== '127.0.0.1') {
      // In production, backend might be on same host different port or subdomain
      return `${window.location.protocol}//${window.location.hostname}:8000`;
    }
  }
  
  // Development default
  return 'http://127.0.0.1:8000';
}

/**
 * Backend API base URL
 * Use this constant throughout the application
 */
export const BACKEND_URL = getBackendUrl();

/**
 * API endpoint builder helper
 * Ensures consistent URL construction
 */
export function apiUrl(endpoint: string): string {
  // Remove leading slash if present to avoid double slashes
  const cleanEndpoint = endpoint.startsWith('/') ? endpoint.slice(1) : endpoint;
  return `${BACKEND_URL}/${cleanEndpoint}`;
}

/**
 * WebSocket URL for real-time features (if needed in future)
 */
export function getWebSocketUrl(): string {
  const baseUrl = getBackendUrl();
  return baseUrl.replace('http://', 'ws://').replace('https://', 'wss://');
}

/**
 * Configuration object for easy access
 */
export const config = {
  backend: {
    baseUrl: BACKEND_URL,
    apiUrl: apiUrl,
    wsUrl: getWebSocketUrl(),
  },
  endpoints: {
    // Health
    health: '/health/health',
    
    // Analysis
    analyze: '/analyze/',
    analyzeReview: '/analyze/review-insights',
    analyzeCancel: '/analyze/cancel',
    
    // Models
    modelsPreferences: '/models/preferences',
    modelsAvailable: '/models/available',
    modelsTestResults: '/models/test-results',
    modelsTestModel: '/models/test-model',
    modelsRecommendations: '/models/recommendations',
    modelsSetupComplete: '/models/setup-complete',
    
    // Upload
    uploadDocuments: '/upload-documents/',
    downloadFile: '/upload-documents/download-file',
    previewFile: '/upload-documents/preview-file',
    
    // Visualization
    visualizeGenerate: '/visualize/generate',
    visualizeGoalBased: '/visualize/goal-based',
    
    // Visualization Enhancement (LIDA-inspired)
    vizEdit: '/viz/edit',
    vizExplain: '/viz/explain',
    vizEvaluate: '/viz/evaluate',
    vizRepair: '/viz/repair',
    vizRecommend: '/viz/recommend',
    vizPersonaGoals: '/viz/persona-goals',
    
    // History
    history: '/history/',
    historyAdd: '/history/add',
    
    // Reports
    generateReport: '/generate-report/',
    downloadReport: '/download-report/',
  },
} as const;

/**
 * Helper to get full endpoint URL
 * @param endpointKey - Key from config.endpoints
 * @returns Full URL for the endpoint
 */
export function getEndpoint(endpointKey: keyof typeof config.endpoints): string {
  return apiUrl(config.endpoints[endpointKey]);
}
